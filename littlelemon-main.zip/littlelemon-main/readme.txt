/api/booking/
/api/menu-items/
/api/menu-items/<int:pk>'
/api/message/
/api/api-token-auth/